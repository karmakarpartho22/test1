﻿function getBlazorCulture() {
    return window.localStorage['BlazorCulture'];
};
function setBlazorCulture(value) {
    window.localStorage['BlazorCulture'] = value;
};

function blazorGetTimezoneOffset() {
    var d = new Date();
    var n = d.getTimezoneOffset();
    return n;
}

function getWindowWidth() {
    var w = window.innerWidth;
    return w;
}
function getWindowHeight() {
    var h = window.innerHeight;
    return h;
}


//to get the width of the left menu
function getNavMenuWidth() {
    var navMenu = document.getElementById('navMenuSideBar');
    return navMenu.style.width;
}

//to set the width of the left menu
function setWidthOfNavbar(widthOfMenu) {
    var navmenu = document.getElementById("navMenuSideBar");
    if (navmenu !== null)
        navmenu.style.width = widthOfMenu;
    return widthOfMenu;
}

//to set the width of the all the grids based on the size of the left menubar
function getFullScreenWidth() {
    //get the width of the screen
    var screenWidth = getWindowWidth();
    var navmenu = document.getElementById("navMenuSideBar");
    if (navmenu !== null) {
        //get the width of the navmenu
        var sideBarWidthinPx = document.getElementById('navMenuSideBar')?.style.width;
        var sideBarWidth = sideBarWidthinPx.substring(0, sideBarWidthinPx.indexOf('p'));
        //final width of the control. we can use this variable to set the full width of the any control
        var finalWidth = (screenWidth - sideBarWidth - 75) + "px";

        var allControls = document.getElementsByClassName('fullWidth');
        for (x in allControls) {
            if (allControls[x]?.localName === 'div') {
                allControls[x].style.width = finalWidth;
            }
        }
        return finalWidth;
    }

    
}
