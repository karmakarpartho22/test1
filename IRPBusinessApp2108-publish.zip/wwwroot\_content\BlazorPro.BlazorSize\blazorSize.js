import { BlazorSizeMedia } from './blazorSizeMedia.js';
import { ResizeListener } from './blazorSizeResize.js';
window.blazorSizeMedia = new BlazorSizeMedia();
window.blazorSize = new ResizeListener();
